# OpenGL-Base
Base new OpenGL project with SDL2

## TODO

* Ajustar o Makefile para funcionar em Linux
